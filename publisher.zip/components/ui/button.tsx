import Link from "next/link";
import { AnchorHTMLAttributes, ButtonHTMLAttributes, ReactNode, forwardRef } from "react";
import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const buttonVariants = cva(
  "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
  {
    variants: {
      variant: {
        default: "bg-primary text-primary-foreground hover:bg-primary/90",
        primary: "bg-primary text-primary-foreground hover:bg-primary/90",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        danger: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        tertiary: "bg-transparent text-primary hover:bg-accent hover:text-accent-foreground",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-10 px-4 py-2",
        md: "h-10 px-4 py-2",
        sm: "h-9 rounded-md px-3",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10",
        "icon-sm": "h-8 w-8",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  }
);

export interface SharedButtonProps extends VariantProps<typeof buttonVariants> {
  children?: ReactNode;
  className?: string;
}

type ButtonAsButtonProps = SharedButtonProps & ButtonHTMLAttributes<HTMLButtonElement> & {
  href?: never;
};

type ButtonAsLinkProps = SharedButtonProps & Omit<AnchorHTMLAttributes<HTMLAnchorElement>, "href"> & {
  href: string;
  disabled?: boolean;
};

export type ButtonProps = ButtonAsButtonProps | ButtonAsLinkProps;

export const Button = forwardRef<HTMLButtonElement | HTMLAnchorElement, ButtonProps>(
  (props, ref) => {
    const { variant = "default", size = "default", className, children, ...rest } = props;
    
    if ("href" in rest && rest.href) {
      const { href, disabled, ...linkProps } = rest as ButtonAsLinkProps;
      return (
        <Link
          href={href}
          className={cn(buttonVariants({ variant, size, className }))}
          aria-disabled={disabled || linkProps["aria-disabled"]}
          tabIndex={disabled ? -1 : linkProps.tabIndex}
          ref={ref as React.ForwardedRef<HTMLAnchorElement>}
          {...linkProps}
        >
          {children}
        </Link>
      );
    }
    
    const { type = "button", ...buttonProps } = rest as ButtonAsButtonProps;
    return (
      <button 
        type={type} 
        className={cn(buttonVariants({ variant, size, className }))} 
        ref={ref as React.ForwardedRef<HTMLButtonElement>}
        {...buttonProps}
      >
        {children}
      </button>
    );
  }
);

Button.displayName = "Button";
